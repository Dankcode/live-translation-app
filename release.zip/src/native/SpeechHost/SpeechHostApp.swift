//
//  SpeechHostApp.swift
//  SpeechHost
//
//  Created by Ryuuna H on 29/01/2026.
//

import SwiftUI

@main
struct SpeechHostApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
