const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');
const { spawn, execSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const { WebSocketServer } = require('ws');

let overlayWindow;
let mainWindow;
let macSttProcess = null;
let wss = null;
let currentMacSttId = null;

const MAC_STT_APP_BIN = path.join(app.getAppPath(), 'bin/SpeechHost.app/Contents/MacOS/SpeechHost');

/**
 * Detects the local IPv4 address.
 */
function getLocalIP() {
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address;
      }
    }
  }
  return '127.0.0.1';
}

/**
 * Initializes the WebSocket server for Satellite STT.
 */
function startWebSocketServer() {
  wss = new WebSocketServer({ port: 8080 });
  console.log('Satellite WebSocket Server started on port 8080');

  wss.on('connection', (ws) => {
    console.log('Satellite Browser connected. Total clients:', wss.clients.size);
    broadcastSatelliteStatus();

    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message.toString());
        if (mainWindow && !mainWindow.isDestroyed()) {
          mainWindow.webContents.send('satellite-transcript', data);
        }
      } catch (e) {
        console.error('Failed to parse WebSocket message:', e);
      }
    });

    ws.on('close', () => {
      console.log('Satellite Browser disconnected. Total clients:', wss.clients.size);
      broadcastSatelliteStatus();
    });
  });
}

function broadcastSatelliteStatus() {
  if (mainWindow && !mainWindow.isDestroyed() && wss) {
    mainWindow.webContents.send('satellite-status', wss.clients.size > 0);
  }
}

function checkMacSttBinary() {
  if (process.platform !== 'darwin') return false;
  return fs.existsSync(MAC_STT_APP_BIN);
}

async function requestPermissions() {
  if (process.platform === 'darwin') {
    const { systemPreferences } = require('electron');
    try {
      const micAccess = await systemPreferences.askForMediaAccess('microphone');
      console.log('Microphone access:', micAccess);
    } catch (e) {
      console.error('Failed to request microphone access:', e);
    }
  }
}

function broadcastOverlayStatus() {
  const visible = overlayWindow ? overlayWindow.isVisible() : false;
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('overlay-status', visible);
  }
}

function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 900,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    },
  });

  const url = 'http://localhost:3000';

  if (app.isPackaged) {
    // In production, start the Next.js server and wait for it to be ready
    const { fork } = require('child_process');
    const nextCli = path.join(app.getAppPath(), 'node_modules/next/dist/bin/next');

    const serverProcess = fork(nextCli, ['start', '-p', '3000'], {
      cwd: app.getAppPath(),
      env: { ...process.env, NODE_ENV: 'production' },
      stdio: 'pipe'
    });

    serverProcess.stdout.on('data', (data) => console.log(`Next.js: ${data}`));
    serverProcess.stderr.on('data', (data) => console.error(`Next.js Error: ${data}`));

    // Check port 3000 periodically
    const checkServer = setInterval(() => {
      const http = require('http');
      const request = http.request({ port: 3000, timeout: 1000 }, (res) => {
        if (res.statusCode === 200 || res.statusCode === 404) {
          clearInterval(checkServer);
          console.log('Next.js server is ready, loading windows...');
          mainWindow.loadURL(url);
          if (overlayWindow) {
            overlayWindow.loadURL('http://localhost:3000/overlay');
          }
        }
      });
      request.on('error', () => { /* Server not ready yet */ });
      request.end();
    }, 1000);

    // Fail after 60 seconds
    setTimeout(() => {
      if (mainWindow && mainWindow.webContents.getURL() === '') {
        clearInterval(checkServer);
        const { dialog } = require('electron');
        dialog.showErrorBox('Startup Error', 'The application server failed to start within 60 seconds.');
      }
    }, 60000);

    app.on('will-quit', () => {
      serverProcess.kill();
    });
  } else {
    mainWindow.loadURL(url);
  }

  // Help debugging in production for now
  // mainWindow.webContents.openDevTools();
}

function createOverlayWindow() {
  overlayWindow = new BrowserWindow({
    width: 1200,
    height: 300,
    transparent: true,
    frame: false,
    alwaysOnTop: true,
    hasShadow: false,
    focusable: true,
    resizable: true,
    show: false,
    type: 'panel',
    backgroundColor: '#00000000',
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    },
  });

  overlayWindow.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
  overlayWindow.setAlwaysOnTop(true, 'screen-saver', 1);
  overlayWindow.setFullScreenable(false);
  overlayWindow.setIgnoreMouseEvents(true, { forward: true });

  const { screen } = require('electron');
  const primaryDisplay = screen.getPrimaryDisplay();
  const { width, height } = primaryDisplay.workAreaSize;
  overlayWindow.setPosition(Math.floor((width - 1200) / 2), height - 250);

  const url = 'http://localhost:3000/overlay';
  if (!app.isPackaged) {
    overlayWindow.loadURL(url);
  }
}

app.whenReady().then(async () => {
  createMainWindow();
  // overlayWindow creation is called inside createMainWindow's server-ready callback if packaged,
  // or immediately if not. Wait, let's keep createOverlayWindow here but only loadURL when ready.
  createOverlayWindow();
  startWebSocketServer();
  await requestPermissions();
});

// --- SATELLITE HANDLERS ---

ipcMain.on('open-satellite-browser', () => {
  shell.openExternal('http://localhost:3000/satellite');
});

ipcMain.on('toggle-overlay', (event) => {
  if (!overlayWindow) {
    createOverlayWindow();
    overlayWindow.show();
  } else {
    if (overlayWindow.isVisible()) overlayWindow.hide();
    else overlayWindow.show();
  }
  event.reply('overlay-status', overlayWindow.isVisible());
  broadcastOverlayStatus();
});

ipcMain.on('get-overlay-status', (event) => {
  event.reply('overlay-status', overlayWindow ? overlayWindow.isVisible() : false);
});

ipcMain.on('check-satellite-status', (event) => {
  event.reply('satellite-status', wss.clients.size > 0);
});

ipcMain.on('broadcast-stt-command', (event, { command, config }) => {
  // 1. Send to Overlay window via IPC (The overlay now acts as the listener)
  if (overlayWindow && !overlayWindow.isDestroyed()) {
    overlayWindow.webContents.send(`${command}-stt`, config);
  }

  // 2. Broadcast to all WebSocket clients (Legacy Browser Satellite)
  if (wss) {
    const payload = JSON.stringify({ type: 'command', command, config });
    wss.clients.forEach((client) => {
      if (client.readyState === 1) { // WebSocket.OPEN
        client.send(payload);
      }
    });
  }
});

ipcMain.on('close-overlay', () => {
  if (overlayWindow) overlayWindow.hide();
  broadcastOverlayStatus();
});

ipcMain.on('resize-overlay', (event, { width, height }) => {
  if (overlayWindow) overlayWindow.setSize(width, height);
});

ipcMain.on('set-ignore-mouse', (event, ignore) => {
  if (overlayWindow) {
    overlayWindow.setIgnoreMouseEvents(ignore, { forward: true });
    // Broadcast status to both windows
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('overlay-lock-status', ignore);
    }
    overlayWindow.webContents.send('overlay-lock-status', ignore);
  }
});

ipcMain.on('satellite-data', (event, data) => {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('satellite-transcript', data);
  }
  // Also broadcast to all WebSocket clients (Viewer/History Sync)
  broadcastToViewers(data);
});

ipcMain.on('broadcast-transcript', (event, data) => {
  broadcastToViewers(data);
});

ipcMain.on('send-subtitle', (event, data) => {
  // Only send to overlay for display
  if (overlayWindow && !overlayWindow.isDestroyed()) {
    overlayWindow.webContents.send('receive-subtitle', data);
  }
});

ipcMain.on('overlay-hover', (event, isHovered) => {
  if (overlayWindow && !overlayWindow.isDestroyed()) {
    overlayWindow.setIgnoreMouseEvents(!isHovered, { forward: true });
  }
});

ipcMain.on('sync-languages', (event, data) => {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('sync-languages', data);
  }
  if (overlayWindow && !overlayWindow.isDestroyed()) {
    overlayWindow.webContents.send('sync-languages', data);
  }
});

ipcMain.on('open-devtools', () => {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.openDevTools({ mode: 'detach' });
  }
  if (overlayWindow && !overlayWindow.isDestroyed()) {
    overlayWindow.webContents.openDevTools({ mode: 'detach' });
  }
});

ipcMain.on('get-local-ip', (event) => {
  event.reply('local-ip', getLocalIP());
});

ipcMain.on('open-external-browser', (event, url) => {
  shell.openExternal(url);
});

/**
 * Broadcasts data to all connected WebSocket clients.
 */
function broadcastToViewers(data) {
  if (wss) {
    const payload = JSON.stringify({
      type: 'transcript',
      ...data,
      timestamp: Date.now() // Use the host computer's time
    });
    wss.clients.forEach((client) => {
      if (client.readyState === 1) { // WebSocket.OPEN
        client.send(payload);
      }
    });
  }
}

ipcMain.on('start-mac-stt', async (event, { locale }) => {
  if (process.platform !== 'darwin') {
    event.reply('mac-stt-error', 'Native STT is only supported on macOS.');
    return;
  }

  if (!checkMacSttBinary()) {
    event.reply('mac-stt-error', 'SpeechHost.app not found in bin/ directory. Please build it in Xcode first.');
    return;
  }

  if (macSttProcess) {
    macSttProcess.kill();
  }

  console.log(`Starting Native Host STT with locale: ${locale}`);
  macSttProcess = spawn(MAC_STT_APP_BIN, [locale]);

  macSttProcess.stdout.on('data', (data) => {
    const lines = data.toString().split('\n');
    for (const line of lines) {
      if (!line.trim()) continue;
      try {
        const json = JSON.parse(line);
        if (json.error) {
          mainWindow.webContents.send('mac-stt-error', json.error);
        } else if (json.transcript) {
          if (!currentMacSttId) currentMacSttId = Date.now();
          const broadcastId = currentMacSttId;
          if (json.isFinal) currentMacSttId = null;

          mainWindow.webContents.send('mac-stt-transcript', { ...json, id: broadcastId });
          // Broadcast to LAN viewers
          broadcastToViewers({ transcript: json.transcript, isFinal: json.isFinal, id: broadcastId });
        }
      } catch (e) {
        console.error('Failed to parse Swift output:', line);
      }
    }
  });

  macSttProcess.stderr.on('data', (data) => {
    console.error(`macOS STT stderr: ${data}`);
  });

  macSttProcess.on('close', (code) => {
    console.log(`macOS STT process exited with code ${code}`);
    macSttProcess = null;
  });
});

ipcMain.on('stop-mac-stt', () => {
  if (macSttProcess) {
    macSttProcess.kill();
    macSttProcess = null;
  }
});

app.on('will-quit', () => {
  if (macSttProcess) macSttProcess.kill();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
